![relation](relationbg.jpg "relation")

该世界观背景的人物所属的歌曲作者，以Niconico动画为主要创作平台的作曲者居多。
打歌画面的背景也是模仿了NICONICO动画。
除了一小部分人物两两相关或者两三人之间的故事有关联以外，大多数为独立的故事。

| 角色   |日文原名|对应乐曲 |初出版本|
| ----------- | ----------- | ---------- | ---------- |
| [奈伊](/relation/NAI.md) |ナイ | テリトリーバトル      | Chunithm Paradise|
|[穴户美铃](/relation/misuzu.md)|宍戸 美鈴| レーイレーイ|Chunithm Crystal|
|[御手洗千里](/relation/chisato.md)|御手洗　千里（みたらい　ちさと）|ロング・スロー・アライブ| Chunithm Crystal Plus